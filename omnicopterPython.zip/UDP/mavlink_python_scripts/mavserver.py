
from multiprocessing import Process
import subprocess


PX4_IP_const = "0.0.0.0"
PX4_input_port = 14540
PX4_output_port = 14550
#end_IP_const = "192.168.137.246"
end_IP_const = "0.0.0.0"


# Forms IP:port strings and runs mavlink-router to form the connections
def runmavrouter(PX4_IP, PX4_port, end_IP, end_port):

    PX4_str = PX4_IP + ":" + str(PX4_port)
    end_str = end_IP + ":" + str(end_port)

    print("PX4_str: ", PX4_str)
    print("end_str: ", end_str)

    subprocess.run(["mavlink-routerd", "-e", end_str, PX4_str])


def commandPX4():
    #subprocess.run(["mavlink-routerd", "-e", "127.0.0.1:4540", "0.0.0.0:14540"])
    #subprocess.run(["mavlink-routerd", "-e", "192.168.137.246:4000", "0.0.0.0:14540"])
    runmavrouter(PX4_IP_const, PX4_input_port, end_IP_const, 4000)


def listen2PX4():
    #subprocess.run(["mavlink-routerd", "-e", "127.0.0.1:4550", "0.0.0.0:14550"])
    #subprocess.run(["mavlink-routerd", "-e", "192.168.137.246:5000", "0.0.0.0:14550"])
    runmavrouter(PX4_IP_const, PX4_output_port, end_IP_const, 5000)


def vicon2PX4():
    #subprocess.run(["mavlink-routerd", "-e", "127.0.0.1:4550", "0.0.0.0:14550"])
    #subprocess.run(["mavlink-routerd", "-e", "192.168.137.246:5000", "0.0.0.0:14550"])
    runmavrouter(end_IP_const, 4001, PX4_IP_const, PX4_input_port)


if __name__ == '__main__':

    cmdProcess = Process(target=commandPX4)
    cmdProcess.start()

    listenProcess = Process(target=listen2PX4)
    listenProcess.start()

    viconProcess = Process(target=vicon2PX4)
    viconProcess.start()
