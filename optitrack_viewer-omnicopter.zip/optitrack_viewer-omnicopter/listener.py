
import sys
import socket
import numpy as np
import struct

def main() -> int:
    localIP     = "127.0.0.1"
    localPort   = 12690
    bufferSize  = 1024

    msgFromServer       = "Hello UDP Client"
    bytesToSend         = str.encode(msgFromServer)

    # Create a datagram socket
    UDPServerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

    UDPServerSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    # Bind to address and ip
    UDPServerSocket.bind((localIP, localPort))

    print("UDP server up and listening")

    # Listen for incoming datagrams
    while(True):
        

        bytesAddressPair = UDPServerSocket.recvfrom(bufferSize)

        message = bytesAddressPair[0]
        address = bytesAddressPair[1]

        # clientMsg = "Message from Client:{}".format(message)
        # clientIP  = "Client IP Address:{}".format(address)
        # print(clientMsg)
        # print(clientIP)    

        #Decode the message based on MsgName (int), payload (int), data
        netMsgID = int.from_bytes( message[0:4], 'big' )
        payloadBytes = int.from_bytes( message[4:8], 'big' )

        print( "NetMsgID is ", netMsgID )
        # print( "Payload in bytes starting at index 8 is ", payloadBytes )
            
        if netMsgID == 2807643820: #NetMsgMat4
            s = parse_NetMsgMat4( message )
            # print( "String is:\n'{}'".format(s) )

        # Sending a reply to client

        UDPServerSocket.sendto(bytesToSend, address)


def parse_NetMsgMat4( message ):
    print( "NetMsgMat4 arrived... Let's look inside" )
    mat4 = np.empty( [4,4] )
    unpack = struct.Struct( ">d" ) #> means big endian
    i = 0
    for r, c in np.ndindex( mat4.shape ):
        f = unpack.unpack( bytes( message[8 + i*8 : 8+i*8 + 8] ) )
        # print( "f is", f[0] )
        mat4[c][r] = f[0]
        i = i + 1
    print(mat4)
    return mat4


if __name__ == '__main__':
   sys.exit(main())